//
//  ViewController.m
//  SampleApp-Xcode
//
//  Created by Luu Lanh on 11/11/15.
//  Copyright © 2015 LuuLanh. All rights reserved.
//

#import "ViewController.h"
#import "MoMoPaySDK.h"

@interface ViewController ()
{
    UILabel *lblMessage;
    UILocalNotification *noti;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NoficationCenterTokenReceived:) name:@"NoficationCenterTokenReceived" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NoficationCenterCreateOrderReceived:) name:@"NoficationCenterCreateOrderReceived" object:nil];

    ///
    [self continueToPaymentOrder];
}

-(void)viewWillAppear:(BOOL)animated
{
    lblMessage.text = @"{MoMo Response}";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSString*) stringForCStr:(const char *) cstr{
    if(cstr){
        return [NSString stringWithCString: cstr encoding: NSUTF8StringEncoding];
    }
    return @"";
}

-(NSMutableDictionary*) getDictionaryFromComponents:(NSArray *)components{
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    // parse parameters to dictionary
    for (NSString *param in components) {
        NSArray *elts = [param componentsSeparatedByString:@"="];
        if([elts count] < 2) continue;
        // get key, value
        NSString* key   = [elts objectAtIndex:0];
        key = [key stringByReplacingOccurrencesOfString:@"?" withString:@""];
        NSString* value = [elts objectAtIndex:1];
        
        ///Start Fix HTML Property issue
        if ([elts count]>2) {
            @try {
                value = [param substringFromIndex:([param rangeOfString:@"="].location+1)];
            }
            @catch (NSException *exception) {
                
            }
            @finally {
                
            }
        }
        ///End HTML Property issue
        if(value){
            value = [self stringForCStr:[value UTF8String]];
        }
        
        //
        if(key.length && value.length){
            [params setObject:value forKey:key];
        }
    }
    return params;
}

-(void)NoficationCenterTokenReceived:(NSNotification*)notif
{
    //Token Replied
    NSLog(@"::MoMoPay Log::Received Token Replied::%@",notif.object);
    lblMessage.text = [NSString stringWithFormat:@"%@",notif.object];
    
    NSString *sourceText = [notif.object stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"com.mservice.momopaysdk.samplexcode.SampleApp://?"] withString:@""];
    sourceText = [sourceText stringByReplacingOccurrencesOfString:@"com.mservice.momopaysdk.samplexcode.SampleApp" withString:@""];
    sourceText = [sourceText stringByReplacingOccurrencesOfString:@"://://" withString:@"://"];
    
    ///fix UT8 String
    sourceText = [sourceText stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ////end fix UTF8 string
    
    NSArray *components = [sourceText componentsSeparatedByString:@"&"];
    
    NSDictionary *response = [self getDictionaryFromComponents:components];//(NSDictionary*)notif.object;
    NSString *status = [NSString stringWithFormat:@"%@",[response objectForKey:@"status"]];
    NSString *message = [NSString stringWithFormat:@"%@",[response objectForKey:@"message"]];
    if ([status isEqualToString:@"0"]) {
        NSLog(@"::MoMoPay Log: SUCESS TOKEN.");
        NSLog(@">>response::%@",notif.object);
        lblMessage.text = @"Your Order proccessing...";
        
        NSLog(@"::MoMoPay log: HASH YOUR DATA and Continue to Payment here");
        
    }else
    {
        if ([status isEqualToString:@"1"]) {
            NSLog(@"::MoMoPay Log: REGISTER_PHONE_NUMBER_REQUIRE.");
        }
        else if ([status isEqualToString:@"2"]) {
            NSLog(@"::MoMoPay Log: LOGIN_REQUIRE.");
        }
        else if ([status isEqualToString:@"3"]) {
            NSLog(@"::MoMoPay Log: NO_WALLET. You need to cashin to MoMo Wallet ");
        }
        else
        {
            NSLog(@"::MoMoPay Log: %@",message);
        }
    }
    
}
-(void)NoficationCenterCreateOrderReceived:(NSNotification*)notif
{
    //Payment Order Replied
//    NSString *responseString = [[NSString alloc] initWithData:[notif.object dataUsingEncoding:NSUTF8StringEncoding] encoding:NSUTF8StringEncoding];
//    
    NSLog(@"::MoMoPay Log::Request Payment Replied::%@",notif.object);
    lblMessage.text = [NSString stringWithFormat:@"Result: %@",notif.object];
    if ([notif.object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *response = [[NSDictionary alloc] initWithDictionary:notif.object];
        
        int status = -1;
        @try {
            
        }
        @catch (NSException *exception) {
            status= [[response objectForKey:@"status"] intValue];
        }
        @finally {
            
        }
        
        if (status==0) {
            NSLog(@"::MoMoPay Log::Payment Success");
        }
        else
        {
            NSLog(@"::MoMoPay Log::Payment Error::%@",[response objectForKey:@"message"]);
        }
        lblMessage.text = [NSString stringWithFormat:@"%@",response];
        //continue your checkout order here
    }
}

-(void)continueToPaymentOrder{
    //Code của bạn
    UIView *paymentArea = [[UIView alloc] initWithFrame:CGRectMake(20, 100, 300, 300)];
    [paymentArea setBackgroundColor:[UIColor whiteColor]];
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(60, 5, 200, 30)];
    lbl.text = @"SAMPLE APP MOMO SDK 2.0";
    lbl.font = [UIFont systemFontOfSize:13];
    [lbl setBackgroundColor:[UIColor clearColor]];
    [paymentArea addSubview:lbl];
    
    lbl = [[UILabel alloc] initWithFrame:CGRectMake(60, 35, 200, 30)];
    lbl.text = @"Pay by MoMo Wallet";
    lbl.font = [UIFont systemFontOfSize:13];
    [lbl setBackgroundColor:[UIColor clearColor]];
    [paymentArea addSubview:lbl];
    
    lblMessage = [[UILabel alloc] initWithFrame:CGRectMake(60, 60, 300, 200)];
    lblMessage.text = @"{MoMo Response}";
    lblMessage.font = [UIFont systemFontOfSize:15];
    [lblMessage setBackgroundColor:[UIColor clearColor]];
    lblMessage.lineBreakMode = NSLineBreakByWordWrapping | NSLineBreakByTruncatingTail;
    lblMessage.numberOfLines = 0;
    [paymentArea addSubview:lblMessage];
    
    //Tạo button Thanh toán bằng Ví MoMo
    NSString *amount = [NSString stringWithFormat:@"25000"];//Số tiền thanh toán ở đây
    NSString *fee = [NSString stringWithFormat:@"0"]; //Phí của bạn đặt ở đây (phí của Merchant)
    NSString *sampleTransId = [NSString stringWithFormat:@"%lld", [@(floor([[NSDate date] timeIntervalSince1970] * 1000)) longLongValue]];
    
    NSString *description = [NSString stringWithFormat:@"Test pay by MoMo. Amount %@", amount]; //Nội dung này sẽ được hiển thị tại Màn hình xác nhận lấy token trên app MoMo
    
    NSString *username = [NSString stringWithFormat:@"UserName"];//Tai khoan dang login de thuc hien giao dich nay (khong bat buoc)
    
    //Buoc 1: Khoi tao Payment info, add button MoMoPay
    NSMutableDictionary *paymentinfo = [[NSMutableDictionary alloc] init];
    [paymentinfo setValue:sampleTransId forKey:MOMO_PAY_CLIENT_MERCHANT_TRANS_ID];
    [paymentinfo setValue:amount forKey:MOMO_PAY_CLIENT_AMOUNT_TRANSFER];
    [paymentinfo setValue:fee forKey:MOMO_PAY_CLIENT_FEE_TRANSFER];//khong bat buoc
    [paymentinfo setValue:description forKey:MOMO_PAY_CLIENT_TRANSFER_DESCRIPTION];
    [paymentinfo setValue:username forKey:MOMO_PAY_CLIENT_USERNAME];
    //    [paymentinfo setValue:yourvalue1 forKey:yourkey1];
    //    [paymentinfo setValue:yourvalue2 forKey:yourkey2];
    
    [[MoMoPayment shareInstant] createPaymentInformation:paymentinfo];
    
    //Buoc 2: add button Thanh toan bang Vi MoMo vao khu vuc ban can hien thi (Vi du o day la vung paymentArea)
    [[MoMoPayment shareInstant] addMoMoPayDefaultButtonToView:paymentArea];
    
    //Code của bạn
    [self.view addSubview:paymentArea];
    
}


@end
