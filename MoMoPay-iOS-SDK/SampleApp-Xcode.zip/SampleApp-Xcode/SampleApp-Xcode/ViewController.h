//
//  ViewController.h
//  SampleApp-Xcode
//
//  Created by Luu Lanh on 11/11/15.
//  Copyright © 2015 LuuLanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)pushNoti:(id)sender;
- (IBAction)cancelNoti:(id)sender;

@end

