package vn.mservice.sdk.SampleApp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import vn.mservice.MoMo_Partner.MoMoConfig;
import vn.mservice.MoMo_Partner.MoMoPayment;
import vn.mservice.MoMo_Partner.MoMoProgressBar;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class MyActivity extends Activity{
    /**
     * Called when the activity is first created.
     */
    LinearLayout ll_Parent;
    Button button;
    private MoMoProgressBar progressBar;
	private TextView tvMessage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ll_Parent = (LinearLayout) findViewById(R.id.ll_Parent_Xml);
        button = new Button(this);
	    button.setText("Thanh toán qua MoMo");
	    tvMessage = (TextView) findViewById(R.id.tvMessage_Xml);
	    ll_Parent.addView(button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(progressBar == null){
                    progressBar = new MoMoProgressBar();
                }
                progressBar.showProgessDialog(MyActivity.this, "Đang gọi ứng dụng MoMo");
                progressBar.forceDimissProgessDialog(MoMoConfig.TIMEOUT_PAYMENT_PROCESS);
                MoMoPayment.requestToken(MyActivity.this, 10000, 0, "", "",
		                "",//merchant code
		                "",
		                "",
		                null);

//	            MoMoPayment.requestToken(MyActivity.this, 10000, 0, "Nạp thẻ game", "Nguyễn Duy Bảo",
//			            "",//merchant code
//			            "Nhà cung cấp",
//			            "Cty ABC",
//			            null);
            }
        });
    }
	public static final char BELL_CHAR = 7;
	public static final String BELL = "" + BELL_CHAR;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(progressBar != null){
            progressBar.dimissProgessDialog();
        }
        if(requestCode == MoMoConfig.GET_INFO && resultCode == RESULT_OK){
            if(data != null){
                if(data.getIntExtra(MoMoConfig.STATUS, -1) == 0){
                    String token = data.getStringExtra(MoMoConfig.DATA);
                    if(token != null && !token.equals("")){
	                    tvMessage.setText(token);
	                    Toast.makeText(this, data.getStringExtra("phonenumber") + data.getStringExtra("session"), Toast.LENGTH_LONG).show();
                        //Thực hiện gọi lên server của bạn
	                    String sessionKey = "44d891984846410abbcbdc5b4f0814d1";

	                    CryptLib cryptLib = null;
	                    try {
		                    cryptLib = new CryptLib();
	                    } catch (NoSuchAlgorithmException e) {
		                    e.printStackTrace();
	                    } catch (NoSuchPaddingException e) {
		                    e.printStackTrace();
	                    }

	                    String decryptData = "";// + phoneNumber.substring(phoneNumber.length() - 9)
	                    try {
//		                    decryptData = cryptLib.decryptAES(token.split(BELL)[1], sessionKey, "");
		                    decryptData = cryptLib.decryptAES("jnxI9JBXmedJXvo79rsi+qwnn29Kg5c0DdEYLke9cDDij98vvO5iaWwUSPMWV/V4d6cun+B1B/8y\n" +
				                    "0AlDUW3XPgINPKmF/g6V5y8gdP8oTX9VAz3WBgYtY97Bma/qfr016N0zIm7berfLM215HwJOt+op\n" +
				                    "cxYGwbgsQQYnD1ubk269SjA2D94IcUzMgdQJITN9D+kImawKJTRuCBVGqvgYt5ZYuIm3vYMOPuOG\n" +
				                    "Tu0MQfq/XckZE36igAqxPkelfcvBwontixIpNeSgFbfQEwCXGOb/MpffKYC8y1gjRbvnxVszynA3\n" +
				                    "WjJnxgGCF396ytNGwUNuCPLbTYjX3wtDRTVcvSf4+sAWmQKVx/jnrAGd1C3V7aThvnPFsAaP3M1R\n" +
				                    "BFko2IhLDEF8EOMXwMg3LbRDJdNXrA0CqD4KxYq/BSIZCzHbvzK1E7XrTdFKM9hMwM2sWIXJdsk7\n" +
				                    "emLnE/gzBadDLUtObMb8Lu/5A9sAVT8XLH4/TKrZMET9sBzuPS/zYJmn8kX5SXBtiWZ40nbOAwXZ\n" +
				                    "UDHGUVp724wAZG6ClyqbWrN4sbuXN9uhq2hcWMx2TJnltDScPwHVAuZvUBgrtPJvkdzx4/Af8o//\n" +
				                    "4GcwSK3Jm6BPougB3kiWXADW39EfnJVsICd4sWHGED0IK42RFjpDQegn1JiQ2ORpoY4l9qbJznSU\n" +
				                    "iXJ5yYpPeYONd2Nz7O5FYZuWBy9mL2W4uxmNzXJJ2intQijtPwfP6bR++IiLtK4LZU23WEjr6ZFn\n" +
				                    "+7wQ+CSSR5hLH/QsnGVGK476sSbBWaOW2WU8VvOijtW7klAQrbH56gr/Suh8FpDsE0DjrFC2bcSi\n" +
				                    "YHuoFVaLgybbo+Q5lQ6wQJMEyiai2V6vL5+iUcPEPXtpqqL/H1kGkeXAHrtM", "777a9ac50068481b934e59e2f6155ac3", "");
		                    Log.d("BAO decryptData", decryptData);
	                    } catch (InvalidKeyException e) {
		                    e.printStackTrace();
	                    } catch (UnsupportedEncodingException e) {
		                    e.printStackTrace();
	                    } catch (InvalidAlgorithmParameterException e) {
		                    e.printStackTrace();
	                    } catch (IllegalBlockSizeException e) {
		                    e.printStackTrace();
	                    } catch (BadPaddingException e) {
		                    e.printStackTrace();
	                    }

                    }else {
                        Toast.makeText(this, "Không nhận được thông tin", Toast.LENGTH_SHORT).show();
                    }
                }else if(data.getIntExtra(MoMoConfig.STATUS, -1) == -1){//Trường hợp gọi qua app version cũ
                    Toast.makeText(this, "Vui lòng cập nhật ứng dụng MoMo Chuyển nhận tiền phiên bản mới nhất", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(this, data.getStringExtra(MoMoConfig.MESSAGE) != null? data.getStringExtra(MoMoConfig.MESSAGE) : "Không nhận được thông tin", Toast.LENGTH_SHORT).show();
                }
            }else {
                Toast.makeText(this, "Không nhận được thông tin", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this, "Không nhận được thông tin", Toast.LENGTH_SHORT).show();
        }
    }

}
