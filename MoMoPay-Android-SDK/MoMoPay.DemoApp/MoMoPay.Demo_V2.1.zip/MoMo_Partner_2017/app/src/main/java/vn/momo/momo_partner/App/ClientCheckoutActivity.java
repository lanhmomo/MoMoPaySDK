/**
 * Created By Bao.Nguyen on Sep 24, 2015
 * Edited by Lanh.Luu,Hung.Do on 2/24/17.
 * https://github.com/lanhmomo/MoMoPaySDK
 */
package vn.momo.momo_partner.App;


import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;


import vn.momo.momo_partner.Client.ClientConfig;
import vn.momo.momo_partner.Client.ClientHttpAsyncTask;
import vn.momo.momo_partner.Client.ClientProceedToCheckout;
import vn.momo.momo_partner.R;

import static vn.momo.momo_partner.Client.ClientConfig.MERCHANT_ALIAS_VALUE;
import static vn.momo.momo_partner.Client.ClientConfig.MERCHANT_CODE_VALUE;
import static vn.momo.momo_partner.Client.ClientConfig.MERCHANT_NAME_VALUE;
import static vn.momo.momo_partner.Client.ClientConfig.MOMO_APP_PAKAGE_CLASS;

public class ClientCheckoutActivity extends Activity implements ClientHttpAsyncTask.RequestToServerListener {
    Button btnPayment;
    TextView tvMessage;
    TextView lblmerchantid;
    TextView lblmerchantname;
    LinearLayout ll_Parent;

    public ClientCheckoutActivity() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Init merchant info and setup environment
        ClientProceedToCheckout.InitMerchant(ClientCheckoutActivity.this, MOMO_APP_PAKAGE_CLASS, MERCHANT_CODE_VALUE, MERCHANT_NAME_VALUE, MERCHANT_ALIAS_VALUE);
        ClientProceedToCheckout.SetupEnvironment(ClientCheckoutActivity.this, ClientConfig.MOMO_ENVIRONMENT.DEVELOPMENT);

        //setup layout
        this.setContentView(R.layout.main);
        this.tvMessage = (TextView)this.findViewById(R.id.tvMessage_Xml);
        this.ll_Parent = (LinearLayout)this.findViewById(R.id.ll_Parent_Xml);
        this.btnPayment = ClientProceedToCheckout.createMoMoPaymentButton(this, this.ll_Parent);
        this.btnPayment.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                int _amout_total = 10000;
                String description_show_on_momo_app = "Ve xem phim CGV";
                String _username = "usernameOrUserId";
                String _useremail = "Useremail@gmail.com";

                ClientProceedToCheckout.getTokenByTID(ClientCheckoutActivity.this,_amout_total,description_show_on_momo_app,_username,_useremail);
            }
        });
        this.lblmerchantid   = (TextView)this.findViewById(R.id.lblmerchantid);
        this.lblmerchantid.setText("Merchant Id: " + MERCHANT_CODE_VALUE);
        this.lblmerchantname = (TextView)this.findViewById(R.id.lblmerchantname);
        this.lblmerchantname.setText("Alias Name : " + MERCHANT_NAME_VALUE);
    }

    protected  void  initBillInfo_Only_forTesting(){


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == -1) {
            if(data != null) {
                if(data.getIntExtra("status", -1) == 0) {
                    Toast.makeText(this, "Get token " + data.getStringExtra("message"), Toast.LENGTH_LONG).show();
                    String token = data.getStringExtra("data");
                    String phoneNumber = data.getStringExtra("phonenumber");
                    if(token != null && !token.equals("")) {
                        if(VERSION.SDK_INT >= 11) {
                            //Send request Payment to server here
                            (new ClientHttpAsyncTask(this, this, phoneNumber)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{token});
                        } else {
                            (new ClientHttpAsyncTask(this, this, phoneNumber)).execute(new String[]{token});
                        }
                    } else {
                        Toast.makeText(this, this.getString(R.string.not_receive_info), Toast.LENGTH_SHORT).show();
                    }
                } else if(data.getIntExtra("status", -1) == 1) {
                    Toast.makeText(this, data.getStringExtra("message") != null?data.getStringExtra("message"):"Thất bại", Toast.LENGTH_SHORT).show();
                } else if(data.getIntExtra("status", -1) == 2) {
                    Toast.makeText(this, this.getString(R.string.not_receive_info), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, this.getString(R.string.not_receive_info), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, this.getString(R.string.not_receive_info), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, this.getString(R.string.not_receive_info), Toast.LENGTH_SHORT).show();
        }

    }

    public void receiveResultFromServer(String result) {
        Log.d("MoMo - receiveResult", result);

        try {
            JSONObject e = new JSONObject(result);
            int status = e.optInt("status");
            if(status == 0) {
                Toast.makeText(this, e.optString("message"), Toast.LENGTH_SHORT).show();
                result = "SUCCESS!\n" + result;
            } else if(status == 1) {
                Toast.makeText(this, e.optString("message"), Toast.LENGTH_SHORT).show();
            } else if(status == 2) {
                Toast.makeText(this, e.optString("message"), Toast.LENGTH_SHORT).show();
            } else if(status == 3) {
                Toast.makeText(this, e.optString("message"), Toast.LENGTH_SHORT).show();
            }
            else{
                result = result + "\n\nHAS ERROR! It's may be come from:";
                result = result + "\n - Merchant info: merchantId, public key, hash value invalid";
                result = result + "\n - MoMo wallet: session timeout, password invalid, credit not enough,..";
            }
        } catch (JSONException var4) {
            var4.printStackTrace();
        }

        this.tvMessage.setText(result);
    }
}